| shape | speedup | status | max_abs | route |
|---|---|---|---|---|
| `row01_hub` | 6.985x | PASS | 0.00142 | table |
| `row02_b1` | 4.430x | PASS | 9.54e-07 | - |
| `row03_b4` | 8.179x | PASS | 0.00114 | - |
| `row04_b16` | 2.259x | PASS | 0.000806 | table |
| `row05_b128` | 4.605x | PASS | 0.00124 | - |
| `row07_d32` | 5.213x | PASS | 0.00107 | table |
| `row08_d1024` | 4.993x | PASS | 0.00146 | table |
| `row09_h1` | 4.772x | PASS | 0.00143 | table |
| `row10_h2` | 5.828x | PASS | 0.00155 | table |
| `row11_h16` | 9.943x | PASS | 0.00143 | table |
| `row12_n32` | 2.548x | PASS | 1.43e-06 | table |
| `row13_n1024` | 17.004x | PASS | 0.00155 | table |
| `row01_hub_pad` | 7.084x | PASS | 0.00142 | table |
| `row02_b1_pad` | 6.825x | PASS | 9.54e-07 | - |
| `row03_b4_pad` | 5.445x | PASS | 0.00114 | - |
| `row04_b16_pad` | 2.555x | PASS | 0.000806 | table |
| `row05_b128_pad` | 4.535x | PASS | 0.00124 | - |
| `row07_d32_pad` | 4.987x | PASS | 0.00107 | table |
| `row08_d1024_pad` | 5.100x | PASS | 0.00146 | table |
| `row09_h1_pad` | 4.865x | PASS | 0.00143 | table |
| `row10_h2_pad` | 6.060x | PASS | 0.00155 | table |
| `row11_h16_pad` | 10.077x | PASS | 0.00143 | table |
| `row12_n32_pad` | 2.528x | PASS | 1.67e-06 | table |
| `row13_n1024_pad` | 16.922x | PASS | 0.00155 | table |

**24/24 passing** | geometric mean **5.574x** | range 2.259x - 17.004x
